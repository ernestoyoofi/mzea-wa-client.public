const fs = require("fs")
const isJsonFormat = require("./is-json")
const path = require("path")

class collectionStore {
  constructor(folders) {
    this.__folder = folders
    this.blocked = "blocked-list"
    this.message = "message-{jid}"
    this.group   = "group-{jid}"
  }
}

class SetupMessageStore {
  constructor({
    folder
  } = {}) {
    const isFolder = fs.existsSync(folder)? fs.lstatSync(folder).isDirectory() : false
    if(!isFolder) {
      require("fs").mkdirSync(folder)
    }
    this.folder = folder
    this.c = new collectionStore(folder)
  }

  /**
   * @name setContacts
   * @param {[{id: string, name?: string, notify?: string, pp_url?: string|null}]} ArrayContact
   * @returns {void}
   * 📑 Add Collection Contact Your Save
   */
  async setContacts(ArrayContact) {
    // ⏱️ Time Quick To Save If Folder Not Recommend
    const __f = path.join(this.folder, "contacts.json")
    const _ready = (fs.existsSync(__f) || fs.lstatSync(__f).isFile() || isJsonFormat(fs.readFileSync(__f), "array"))
    if(!_ready) {
      fs.writeFileSync(__f, '{}', "utf-8")
    }

    const data = JSON.parse(await fs.promises.readFile(__f, "utf-8"))
    data["timeUpdate"] = new Date()
    ArrayContact.map(z => {
      if(z.imgURl === "change") {
        return ;
      }
      data[z.id] = {
        contact_name: typeof z.name != "string"?data[z.id]?.contact_name||null:z.name,
        whatsapp_name: typeof z.notify != "string"?data[z.id]?.whatsapp_name||null:z.notify,
        pp_urls: typeof z.pp_url != "string"?null:z.pp_url?.match("https://")? z.pp_url : null
      }
    })

    fs.promises.writeFile(__f, JSON.stringify(data,null,2), "utf-8")
  }

  /**
   * @name getContacts
   * @returns {{total: number, list:[{id: string, name: string, verifiedName?: string, pp_url: string|null}]}}
   */
  getContacts() {
    
  }

  setGroup(ArrayGroup) {
    if(!Array.isArray(ArrayGroup)) {
      throw new Error("Only Array To Create Updates !")
    }
    ArrayGroup.forEach(GroupMetadata => {
      const pathGroup = path.join(this.folder, `${this.c.group.replace(/{jid}/g, GroupMetadata.id)}.json`)

      if(!fs.existsSync(pathGroup)) {
        fs.writeFileSync(pathGroup, '{"participants":[]}', "utf-8")
      }
      const data = JSON.parse(fs.readFileSync(pathGroup, "utf-8"))
      if(Array.isArray(GroupMetadata.participants)) {
        GroupMetadata.participants.forEach(user => {
          const i_user = data.participants.map(z=>z.id).indexOf(user.id)
          if(i_user != -1) {
            data.participants[i_user] = user
          } else {
            data.participants.push(user)
          }
        })
      }
      Object.keys(GroupMetadata).forEach(key => {
        if(key != "participants") {
          data[key] = GroupMetadata[key]
        }
      })

      fs.writeFileSync(pathGroup, JSON.stringify(data,null,2), "utf-8")
    })
  }

  getGroup(jid) {
    const BuildPaths = path.join(this.folder, `${this.c.group.replace(/{jid}/g, jid)}.json`)
    if(!fs.existsSync(BuildPaths)) {
      return Promise.reject(new Error("Can't find this group by msgstore"))
    }

    return JSON.parse(fs.readFileSync(BuildPaths, "utf-8"))
  }
}

module.exports.collectionStore = collectionStore
module.exports.SetupMessageStore = SetupMessageStore
