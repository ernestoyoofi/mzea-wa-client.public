const { useMultiFileAuthState, DisconnectReason } = require("@adiwajshing/baileys")
const QRCODE_Scan = require("qrcode-terminal")
const WhatsApp_Websocket = require("@adiwajshing/baileys").default
//const WhatsApp_Websocket = require("@whiskeysockets/baileys").default
const P = require("pino")
const { SetupMessageStore } = require("./storemsg")
const { mapEvent, eventsRegister } = require("./keymap")
const { MessageEdit } = require("./modif/message")

class WhatsAppSetup {
  constructor({
    msgstore,
    pino_level,
    auth_folder,
  } = {}) {
    this.pino_level = pino_level||"silent"
    this.auth_folder = auth_folder||`${process.cwd()}/auth`,
    this.msgstore = msgstore||`${process.cwd()}/chat`,
    this.event = undefined
    this.socket = undefined
    this.event_fc = {}
    this.db_store = new SetupMessageStore({ folder: this.msgstore })
  }

  async start_run(title) {
    if(typeof title === "string") {
      process.stdout.write(`\x1b]2;${title}\x1b\x5c`)
    }
    // 📃 Authenticate Client
    const { state, saveCreds } = await useMultiFileAuthState(this.auth_folder)
    const socketing = WhatsApp_Websocket({
      auth: state,
      logger: P({ level: this.pino_level }),
      printQRInTerminal: false,
      syncFullHistory: false,
    })
    
    socketing.sendMsg = async (jid, recept, options) => {
      const isGroup = jid.split("@")[1] === "g.us"
      let grups = {}
      if(isGroup) {
        try {
          grups = this.db_store.getGroup(jid)
        } catch(err) {}
      }
      let includeTags = []
      for(let a of (recept.text || recept.caption || "").split(" ")) {
        if(a.slice(0, 1) === "@" && !isNaN(a.replace("@", ""))) {
          includeTags.push(`${a.replace("@","")}@s.whatsapp.net`)
        }
      }
      console.log(includeTags)
      return socketing.sendMessage(jid, {
        ...recept,
        mentions: includeTags
      }, {
        ephemeralExpiration: grups.ephemeralDuration,
        ...options
      })
    }
    socketing.ev.on("groups.update", (e) => {
      this.db_store.setGroup(e)
    })
    socketing.ev.on("groups.upset", (e) => {
      this.db_store.setGroup(e)
    })
    socketing.ev.on("creds.update", saveCreds)
    socketing.ev.on("connection.update", (conn) => {
      // 🤳 QRCODE SCANNING
      if(typeof conn.qr === "string") {
        console.log(' [    👇 Scan This QR Code To Sign In Your WhatsApp !     ]')
        QRCODE_Scan.generate(conn.qr, { small: true })
      }
      
      if(conn.connection === "close") {
        const shouldReconnect = conn.lastDisconnect.error.output?.statusCode !== DisconnectReason.loggedOut
        if(shouldReconnect) {
          console.log(conn.lastDisconnect.error)
          console.log("📭 Try Connecting...")
          this.start_run()
        } else {
          console.log("⏱️ Connection Close !")
          console.log("Check your connection or whatsapp session !")
          process.exit(1)
        }
      }
      if(conn.connection === "open") {
        socketing.groupFetchAllParticipating().then(z => {
          let a = []
          Object.keys(z).forEach(key => {
            a.push(z[key])
          })
          this.db_store.setGroup(a)
        })
      }
    })
    Object.keys(this.event_fc).forEach((keys) => {
      const i_select = eventsRegister.map(z => z.fc_name).indexOf(keys)
      const getNamedT = eventsRegister.map(z => z.name)[i_select]
      const baileys_mt = eventsRegister.map(z => z.baileys)
      if(i_select != -1 && Array.isArray(baileys_mt[i_select])) {
        for(let key_select of baileys_mt[i_select]) {
          if(getNamedT === "message") {
            return socketing.ev.on(key_select, (e) => {
              if(e.messages[0].message) {
                const v2 = Object.keys(e.messages[0].message).indexOf("viewOnceMessageV2") != -1
                const imViews = e.messages[0].message[v2? "viewOnceMessageV2":"viewOnceMessageV2Extension"]
                if(imViews != null) {
                  delete e.messages[0].message[v2? "viewOnceMessageV2":"viewOnceMessageV2Extension"]
                  e.messages[0].message["onceMedia"] = true
                  e.messages[0].message[Object.keys(imViews.message)[0]] = imViews.message[Object.keys(imViews.message)[0]]
                }
              }
              const _m = MessageEdit(e, socketing)
              if(!_m) {
                return;
              }
              this.event_fc[keys](_m)
            })
          }
          if(getNamedT === "contacts") {
            socketing.ev.on(key_select, (e) => {
              this.db_store.setContacts(e)
            })
          }
          socketing.ev.on(key_select, this.event_fc[keys])
        }
      }
    })

    // 📑 Append Variable
    this.socket = socketing
  }

  /**
   * @name on
   * @param {"message"|"groups"|"groups.participants"|"contacts"|"blocks"} events 
   * @param {mapEvent[events.length]} callback 
   * 📃 Event Of Message Calling Back
   */
  on(events, callback) {
    const i_search_events = eventsRegister.map(z => z.name).indexOf(events)
    const map_fc_name = eventsRegister.map(z => z.fc_name)
    // ✍️ validation
    if(this.event_fc[map_fc_name[i_search_events]]) { throw new Error("Only one to append this function") }
    if("function" != typeof callback) { throw new Error("Callback is not a function !") }
    // ⏱️ Appended
    this.event_fc[map_fc_name[i_search_events]] = callback
  }
}

module.exports.WhatsAppSetup = WhatsAppSetup
