const { downloadMediaMessage } = require("@adiwajshing/baileys")
const fs = require("fs")

function isObjectsKeys(wa, search) {
  return Object.keys(wa.message).indexOf(search) != -1?true:false
}

function GeneratedID(lengths = 10) {
  return require('crypto').randomBytes(lengths).toString("hex")
}

function GetMaterialBucket(wa, socketing) {
  const sdBucket = wa.key.remoteJid
  const getBef = sdBucket.split("@")[1]==="g.us"?"group":sdBucket.split("@")[1]==="s.whatsapp.net"? "private": "broadcast"

  return {
    sender: (getBef === "private" && wa.key.fromMe)?
          `${socketing.user.id.split(":")[0]}@s.whatsapp.net`:
          getBef === "private"? sdBucket:
          wa.key.participant,
    jid: sdBucket,
    isGroup: getBef === "group",
    isPrivate: getBef === "private",
  }
}

function DownloadConv(wa) {
  return async function DownloadMedia(path=".") {
    const buildExtension = isObjectsKeys(wa, "stickerMessage")?
        `${wa.message.stickerMessage.isAnimated?"ani":""}.webp`:
        isObjectsKeys(wa, "imageMessage")?
        `${wa.message.imageMessage.mimetype.split("/")[1]}`:
        isObjectsKeys(wa, "videoMessage")?
        `${wa.message.videoMessage.mimetype.split("/")[1]}`:
        isObjectsKeys(wa, "documentMessage")?
        `${wa.message.documentMessage.mimetype.split("/")[1]}`:null
    if(!buildExtension || buildExtension === null) {
      return Promise.reject(new Error("Hanya pesan media yang dapat diunduh"))
    }
    const buff = await downloadMediaMessage(wa, "buffer")
    const paths = `${path}/${GeneratedID()}.${buildExtension}`

    fs.writeFileSync(paths, buff, "buffer")
    return paths
  }
}

function GetCommand(text) {
  const spliters = text.split(" ")
  const perfix = "!/#%$.".split("")
  if(perfix.indexOf(spliters[0]) != -1) {
    return {
      perfix: spliters[0],
      command: spliters[1]?.toLowerCase(),
      query: spliters.slice(2, spliters.length).join(" "),
      argv: spliters.slice(2, spliters.length).join(" ").split("|")
    }
  }
  if(perfix.indexOf(spliters[0].slice(0, 1)) != -1) {
    return {
      perfix: spliters[0].slice(0, 1),
      command: spliters[0].slice(1, spliters[0].length)?.toLowerCase(),
      query: spliters.slice(1, spliters.length).join(" "),
      argv: spliters.slice(1, spliters.length).join(" ").split("|")
    }
  }
  return {}
}

function GetTextMessage(wa) {
  const repar = isObjectsKeys(wa, "conversation")? wa.message.conversation:
  isObjectsKeys(wa, "extendedTextMessage")? wa.message.extendedTextMessage.text:
  isObjectsKeys(wa, "imageMessage")? wa.message.imageMessage.caption:
  isObjectsKeys(wa, "videoMessage")? wa.message.videoMessage.caption:
  isObjectsKeys(wa, "videoMessage")? wa.message.videoMessage.caption:
  isObjectsKeys(wa, "documentWithCaptionMessage")? wa.message.documentWithCaptionMessage.message.documentMessage.caption:null

  if(typeof repar != "string") {
    return ""
  }
  return repar
}

function GetQuotedMsg(wa) {
  const qt_s = isObjectsKeys(wa, "extendedTextMessage")? wa.message.extendedTextMessage.contextInfo:
  isObjectsKeys(wa, "imageMessage")? wa.message.imageMessage.contextInfo:
  isObjectsKeys(wa, "videoMessage")? wa.message.videoMessage.contextInfo:
  isObjectsKeys(wa, "videoMessage")? wa.message.videoMessage.contextInfo:
  isObjectsKeys(wa, "documentWithCaptionMessage")? wa.message.documentWithCaptionMessage.message.documentMessage.contextInfo:null

  if(typeof qt_s != "object" || Array.isArray(qt_s)) {
    return {}
  }
  return qt_s
}

function MessageEdit(WAMessage, socketing) {
  if(WAMessage.type != "notify") {
    return undefined;
  }
  if(!WAMessage.messages[0].message) {
    return undefined;
  }
  const dataCollect = WAMessage.messages[0]
  const qutMs = GetQuotedMsg(dataCollect)
  let qutSmq = {}
  if(qutMs?.stanzaId) {
    qutSmq = {
      dwn: DownloadConv({
        message: qutMs.quotedMessage
      }),
      key: {
        id: qutMs?.stanzaId,
        participant: qutMs?.participant,
        fromMe: qutMs?.participant?.split("@")[0] === socketing.user.id.split(":")[0],
        remoteJid: qutMs?.remoteJid || GetMaterialBucket(dataCollect, socketing).jid
      }
    }
  }
  return {
    ...GetMaterialBucket(dataCollect, socketing),
    text: GetTextMessage(dataCollect),
    dwn: DownloadConv(dataCollect),
    ...GetCommand(GetTextMessage(dataCollect)),
    quoted: {
      ...qutMs,
      ...qutSmq
    },
    ...dataCollect,
  }
}

module.exports = {
  MessageEdit
}
