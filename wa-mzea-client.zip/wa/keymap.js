const eventsRegister = [
  { 
    name: "message",
    fc_name: "messagesEvent",
    baileys: [ "messages.upsert" ]
  },
  {
    name: "groups",
    fc_name: "groupsEvent",
    baileys: [ "groups.upsert", "groups.update" ]
  },
  {
    name: "groups.participants",
    fc_name: "groupsUserEvent",
    baileys: [ "group-participants.update" ]
  },
  { 
    name: "contacts",
    fc_name: "contactsEvent",
    baileys: [ "contacts.upsert", "contacts.update" ]
  },
  {
    name: "blocks",
    fc_name: "blocksEvent",
    baileys: [ "blocklist.set", "blocklist.update" ]
  },
  {
    name: "call",
    fc_name: "callEvents",
    baileys: [ "call" ]
  }
]

const mapEvent = {
  "message": () => ([
    {
      key: {
        id: string
      }
    }
  ]),
  "groups.participants": () => ([
    {
      id: string,
      action: "add"|"remove",
      participants: []
    }
  ]),
  "contacts": () => ([
    {
      id: string,
      name: string,
      notify: string
    }
  ]),
  "blocks": () => ({
    action: "add"|"remove",
    list: array
  })
}

module.exports = {
  eventsRegister,
  mapEvent
}