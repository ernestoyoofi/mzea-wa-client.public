/**
 * @name isJsonFormat
 * @param {string} string 
 * @param {"array"|"object"} focus 
 * @returns {true|false}
 */
module.exports = (string, focus = "object") => {
  try {
    const objects = JSON.parse(string)

    if(focus === "array" && Array.isArray(objects)) {
      return true
    } else if(focus === "object" && !Array.isArray(objects)) {
      return true
    } else {
      return false
    }
  } catch(err) {
    return false
  }
}